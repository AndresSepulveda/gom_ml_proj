The python codes here include main model structure for the work "GoM ML application to SSHa prediction"

Note: in the srcnn code, the optimal model is selected using another metrics for test.
